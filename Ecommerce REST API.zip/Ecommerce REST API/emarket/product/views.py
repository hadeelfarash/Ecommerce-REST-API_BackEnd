from django.shortcuts import  get_object_or_404 
from rest_framework.decorators import api_view,permission_classes
from rest_framework.response import Response
from .models import Prodcut, Review
from .serializers import ProductSerializer
from .filters import ProductsFilter
from rest_framework.permissions import IsAuthenticated,IsAdminUser
from rest_framework.pagination import PageNumberPagination
from rest_framework import status
from django.db.models import Avg

# Create your views here.
@api_view(['GET'])
def get_all_products(request):
    filterset=ProductsFilter(request.GET,queryset=Prodcut.objects.all().order_by('id'))     # products=Prodcut.objects.all()

    resPage=2 #  HadeelFarash: number of item per page using PageNumberPagenation class
    paginator=PageNumberPagination()
    paginator.page_size=resPage

    queryset=paginator.paginate_queryset(filterset.qs,request)
   
    serializer=ProductSerializer(queryset,many=True)  # serializer=ProductSerializer(products,many=True)
    return Response({"products":serializer.data})

@api_view(['GET'])
def get_by_id_product(request,pk):
    products=get_object_or_404(Prodcut,id=pk)
    serializer=ProductSerializer(products,many=False)
    return Response({"product":serializer.data})

# HadeelFarash : to nem product on nother way "without using admin panel"
# to test via postman i will need every row in Product model exept "createAt" becuase its automatecly add and "user" because it automatecly add via token"register information"
@api_view(['POST'])
@permission_classes([IsAuthenticated,IsAdminUser])

def new_product(request):
    data=request.data
    serializer=ProductSerializer(data=data)
    if serializer.is_valid():
        product=Prodcut.objects.create(**data,user=request.user)
        res=ProductSerializer(product,many=False)

        return Response({"product":res.data})
    else:
        return Response(serializer.errors)



# HadeelFarash : to edit product item on nother way "without using admin panel"
@api_view(['PUT'])
@permission_classes([IsAuthenticated,IsAdminUser])

def update_product(request,pk):
    product=get_object_or_404(Prodcut,id=pk)
    # to enchure the user will edit are the same was added it 
    if product.user != request.user:
        return Response({
            "error":"sorry you can not update this product"},
            status=status.HTTP_403_FORBIDDEN
        )
    product.name=request.data['name']
    product.description=request.data['description']
    product.price=request.data['price']
    product.brand=request.data['brand']
    product.category=request.data['category']
    product.ratings=request.data['ratings']
    product.stock=request.data['stock']
    # now we nedd to update this editing on data base vis serializer
    product.save()
    # now we need to send message for user  to know there editing add succesfully via serializer
    serializer=ProductSerializer(product,many=False)
    return Response({"product":serializer.data})


# HadeelFarash : to delete product item on nother way "without using admin panel"
@api_view(['DELETE'])
@permission_classes([IsAuthenticated,IsAdminUser])

def delete_product(request,pk):
    product=get_object_or_404(Prodcut,id=pk)
    # to enchure the user will delete are the same was added it 
    if product.user != request.user:
        return Response({
            "error":"sorry you can not update this product"},
            status=status.HTTP_403_FORBIDDEN
        )
    
    # now we nedd to update this editing on data base vis serializer
    product.delete()
    # now we need to send message for user  to know there editing add succesfully via serializer
    return Response({"details":"delete done"},status=status.HTTP_200_OK) # this "HTTP_200_OK" mean the operation done successfully



@api_view(['POST'])
@permission_classes([IsAuthenticated])

def create_review(request,pk):
    user=request.user
    product=get_object_or_404(Prodcut,id=pk)
    data=request.data
    review=product.reviews.filter(user=user) # we obtain this "reviews" from name of Modele related_name

    if data['rating'] <=0 or data['rating'] >5: 
        return Response({"error":"please select from 1 to 5"}, status=status.HTTP_400_BAD_REQUEST)
    elif review.exists():
        new_review={'rating':data['rating'],'comment':data['comment']}
        review.update(**new_review)

        return Response({'details':'Product review updated'})
    else:
        Review.objects.create(
            user=user,
            product=product,
            rating=data['rating'],
            comment=data['comment']
        )
        rating=product.reviews.aggregate(avg_rating=Avg('rating')) # to find the rating average for this product
        product.ratings=rating['avg_rating'] # rating update
        product.save()
        return Response({'details':'product review created'})
    

# HadeelFarash : to delete review
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])

def delete_review(request,pk):
    user=request.user
    product=get_object_or_404(Prodcut,id=pk)
    review=product.reviews.filter(user=user)    
    
    if review.exixts():
        review.delete()
        rating=product.reviews.aggregate(avg_ratings=Avg('rating'))
        if rating['avg_ratings'] is None:
            rating['avg_ratings']=0
            product.ratings=rating['avg_ratings']
            product.save()
            return Response({'details':'product review deleted'})
        else:
            return Response({'error':'Review not found'},status=status.HTTP_404_NOT_FOUND)        