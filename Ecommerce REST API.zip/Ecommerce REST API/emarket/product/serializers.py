from rest_framework import serializers
from .models import Prodcut,Review

class ProductSerializer(serializers.ModelSerializer):
    reviews=serializers.SerializerMethodField(method_name='get_reviews',read_only=True) # to show all review for each product,, "get_reviews" : the name of function will fetch the reviews,, read_only=True means just for read without editing from any one 
    class Meta:
        model=Prodcut
        fields="__all__"
        # fields=('name','price','brand')
    def get_reviews(self,obj): # "self" means this functin follow the class , "obj" meane this fun will return object (comment , id , user, date .....)
        reviews=obj.reviews.all()
        serializer=ReviewSerializer(reviews,many=True) # "many = true" may more than one review will be found 
        return serializer.data
    
class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model=Review
        fields="__all__"
