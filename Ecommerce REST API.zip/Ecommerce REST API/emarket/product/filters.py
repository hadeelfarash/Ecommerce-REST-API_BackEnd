import django_filters # type: ignore
from .models import Prodcut

class ProductsFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='iexact')
    keyword=django_filters.filters.CharFilter(field_name="name",lookup_expr="icontains")
    minPrice=django_filters.filters.NumberFilter(field_name="price" or 0,lookup_expr="gte") #gte: greter than
    maxPrice=django_filters.filters.NumberFilter(field_name="price" or 100000,lookup_expr="lte") #lte : less than

    class Meta:
        model = Prodcut
        # fields = ['category', 'brand']
        fields = ('category','brand','keyword','minPrice','maxPrice')