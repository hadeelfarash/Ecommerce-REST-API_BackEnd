from django.db import models
from operator import mod 
from django.contrib.auth.models import User # to know who make the order
from product.models import Prodcut,Review #if i  need to connect with a model that out of app i need to join app name so we write "product."
# Create your models here.

class OrderStatus(models.TextChoices):
    PROCESSING='Processing' # when the user make order
    SHIPPED='shipped' # when the system chech up the order and send it 
    DELIVERED='processing' #when the user take his order


class PaymentStatus(models.TextChoices):
    PAID='Paid' # تم الدفع
    UNPAID='unpaid' # لم يتم الدفع

class PaymentMode(models.TextChoices): # الية الدفع
    COD='Cod' #Cach on delivered
    CARD='Card' # by acrd

class Order(models.Model): # الية الدفع
    city=models.CharField(max_length=400,default="",blank=False)
    zip_code=models.CharField(max_length=100,default="",blank=False)
    street=models.CharField(max_length=500,default="",blank=False)
    state=models.CharField(max_length=100,default="",blank=False)
    country=models.CharField(max_length=400,default="",blank=False)
    phone_nomber=models.CharField(max_length=100,default="",blank=False)
    total_amount=models.IntegerField(default=0)
    payment_status=models.CharField(max_length=30,choices=PaymentStatus.choices,default=PaymentStatus.UNPAID)
    payment_mode=models.CharField(max_length=30,choices=PaymentMode.choices,default=PaymentMode.COD)
    status=models.CharField(max_length=60,choices=OrderStatus.choices,default=OrderStatus)
    user=models.ForeignKey(User,null=True,on_delete=models.SET_NULL)
    createdAt=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.id )# to return id but first should return id as string because this function for string values
    
# HadeelFarash : now i need to join the product with order
class OrderItem(models.Model): 
    product=models.ForeignKey(Prodcut,null=True,on_delete=models.SET_NULL)# the product musnt deleted if the user delet his order
    order=models.ForeignKey(Order,null=True,on_delete=models.CASCADE,related_name='orderitems') #CASCADE because the order you make should by found in order list
    name=models.CharField(max_length=200,default="",blank=False)
    quantity=models.IntegerField(default=1)
    price=models.DecimalField(max_digits=7,decimal_places=2,blank=False)


    

    def __str__(self):
        return self.name