from django.contrib import admin
from .models import Order,OrderItem # i can replace "Order,OrderItem" by * which means import all models 

# Register your models here.
admin.site.register(Order)
admin.site.register(OrderItem)