# HadeelFarash: to deal with error in each app " error handle"
from django.http import JsonResponse
from rest_framework.response import responses
#HadeelFarash : this to deal with error from user 
def handler404(request,exception):
    message=('path not found')
    response=JsonResponse(data={'error':message})
    response.status_code=404
    return response


# HadeelFarash : this to deal with error from server 

def handler500(request):
    message=('Internal server error.')
    response=JsonResponse(data={'error':message})
    response.status_code=500
    return response
# def handler404(request, exception):
#     return render(request, 'error_pages/404.html', status=404)

# def handler500(request):
#     return render(request, 'error_pages/500.html', status=500)
