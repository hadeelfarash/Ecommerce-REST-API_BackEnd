from django.db import models
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import post_save
# Create your models here.

class Profile(models.Model):
    user=models.OneToOneField(User,related_name='profile',on_delete=models.CASCADE)
    reset_password_token=models.CharField(max_length=50,default="",blank=True)
    reset_password_expire=models.DateTimeField(null=True,blank=True)

    
#HadeelFarash : this to automatic profile create when user singup "register"
@receiver(post_save, sender=User) #when create a new user account automaticly send sign to profile to create profile for this user 
def save_profile(sender,instance,created,**kwargs):

    print('instance',instance)
    user=instance

    if created:
        Profile=Profile(user=user)
        Profile.save()